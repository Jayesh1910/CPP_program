/*Example: NEW OPERATOR: InfoBrother*/

#include<iostream>
#include<stdlib.h> //exit() function:
using namespace std;

main()
{
    cout<<"\t\t\t MARKS CALCULATOR";
    int no,i,ans; //no= total No of Sunject, i=for Loop.
    
    //*subject=for enter Subject max, sum=for getting Sum.
    float *subject, sum, percentage;

cout<<"\n\n";    
cout<<" Enter Total Number Of Subject: ";
cin>>no;    

subject=new float[no]; //new Operator to Allocate Memory.
if(subject!=NULL) //error chacker.
{ //Main If IN:
    cout<<"\n\n";
cout<<" Enter Subjects Marks: "<<endl;

for(i=0;i<no;i++) //loop for Getting Data:
{
     //As i=0, so if we want to start from 1,
    cout<<"Subject No "<<(i+1)<<" ";
    cin>>subject[i]; //then we need (i+1) = 1.
    sum+=*subject;
    percentage=sum/(100*no)*100;
}
/**********************************************/
//Display Data:

cout<<"\n\n";
cout<<"\t\t Press 1 to Display: "<<endl;
cout<<"\t\t Press 2 to Exit: "<<endl;
cout<<"\n Your Ans= ";
cin>>ans;
cout<<"\n\n";

if(ans==1) //ans Chacker.
{
    cout<<"\t Subject: \t Max: "<<endl;
    cout<<"\n";
    for(i=0;i<no;i++) //Loop To Read and Print Data.
     {
         cout<<"\tSubject No"<<(i+1)<<"\t"<<*subject<<endl;
         subject++;
     }
     cout<<"\t==================";
     cout<<" \n\tThe Sum is: \t"<<sum;
     cout<<" \n\tPercentage is:\t"<<percentage<<" %";
}
else
{
    cout<<"Thank You...!!"<<endl;
    exit(0);
}



} //main IF out:
    
else
{
    cout<<"Sorry...!! Memory Not Allocated"<<endl;
    cout<<" Chack Your Code Again: ";
    exit(0);
}


return 0;
}